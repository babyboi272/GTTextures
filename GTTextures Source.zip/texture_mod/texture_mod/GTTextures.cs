﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using BepInEx;
using UnityEngine;

namespace GorillaTextureReplacer
{
    [BepInPlugin("com.BabyBoi.gorillatag.GTTextures", "GTTextures", "1.1.1")]
    [BepInProcess("Gorilla Tag.exe")]
    public class TextureReplacementMod : BaseUnityPlugin
    {
        private string texturePath = "";
        private bool showGUI = true;
        private Rect windowRect = new Rect(20f, 20f, 500f, 900f);
        private string statusMessage = "";
        private List<Camera> allCameras = new List<Camera>();
        private int currentCameraIndex;
        private string lookedAtObjectInfo = "";
        private Vector2 scrollPosition;
        private Dictionary<string, Texture2D> loadedTextures = new Dictionary<string, Texture2D>();
        private float tileSize = 1f;
        private Texture2D playerTexture;
        private bool changePlayerTexture;
        private string lookedAtTextureName = "";
        private Vector2 textureNameScrollPosition;
        private float blurAmount;
        private float textureScale = 1f;
        private float pixelationAmount = 1f;
        private string texturePackPath = "";
        private float qualitySlider = 1f;
        private string repetitionCountInput = "1";
        private int repetitionCount = 1;
        private float darknessAmount = 0.5f;
        private float contrastAmount = 1.2f;
        private bool enableRandomTextures = false;
        private float randomTextureInterval = 5f;
        private float lastRandomTextureTime = 0f;
        private List<string> texturePool = new List<string>();
        private bool enableTextureAnimation = false;
        private float textureAnimationSpeed = 1f;
        private int currentAnimationFrame = 0;
        private List<Texture2D> animationFrames = new List<Texture2D>();
        private bool enableProceduralTextures = false;
        private float proceduralNoiseScale = 1f;
        private Color proceduralColor1 = Color.white;
        private Color proceduralColor2 = Color.black;
        private string texturePacksFolder;
        private List<string> availableTexturePacks = new List<string>();
        private Vector2 texturePackScrollPosition;
        private bool showTexturePackBrowser = false;
        private string selectedTexturePack = "";
        private readonly Rect defaultWindowRect = new Rect(20f, 20f, 500f, 900f);
        private Dictionary<GameObject, Dictionary<string, Texture>> originalTextures = new Dictionary<GameObject, Dictionary<string, Texture>>();
        private bool showGuiButton = true;
        private void Awake()
        {
            Debug.Log("Texture Replacer mod is awake!");
            InitializeTexturePackBrowser();
        }



        private void InitializeTexturePackBrowser()
        {
            texturePacksFolder = Path.Combine(Paths.PluginPath, "TexturePacks");
            if (!Directory.Exists(texturePacksFolder))
            {
                Directory.CreateDirectory(texturePacksFolder);
            }
            RefreshTexturePacks();
        }

        private Texture2D CreateTiledTexture(Texture2D originalTexture, int repetitions)
        {
            int newWidth = originalTexture.width * repetitions;
            int newHeight = originalTexture.height * repetitions;
            Texture2D tiledTexture = new Texture2D(newWidth, newHeight);

            for (int y = 0; y < repetitions; y++)
            {
                for (int x = 0; x < repetitions; x++)
                {
                    Color[] pixels = originalTexture.GetPixels();
                    tiledTexture.SetPixels(
                        x * originalTexture.width,
                        y * originalTexture.height,
                        originalTexture.width,
                        originalTexture.height,
                        pixels
                    );
                }
            }

            tiledTexture.Apply();
            return tiledTexture;
        }

        private void RefreshTexturePacks()
        {
            availableTexturePacks.Clear();
            string[] zipFiles = Directory.GetFiles(texturePacksFolder, "*.zip");
            availableTexturePacks.AddRange(zipFiles.Select(Path.GetFileName));
        }

        private void LoadPlayerTexture()
        {
            playerTexture = LoadTextureFromFile(texturePath);
            if (playerTexture != null)
            {
                if (repetitionCount > 1)
                {
                    playerTexture = CreateTiledTexture(playerTexture, repetitionCount);
                }
                statusMessage = "Player texture loaded successfully.";
                return;
            }
            statusMessage = "Failed to load player texture.";
        }

        private Texture2D LoadTextureFromFile(string filePath)
        {
            if (string.IsNullOrEmpty(filePath))
            {
                statusMessage = "No texture path provided.";
                return null;
            }

            if (!File.Exists(filePath))
            {
                statusMessage = "Texture file not found: " + filePath;
                Debug.LogError("Texture file not found: " + filePath);
                return null;
            }

            if (loadedTextures.ContainsKey(filePath))
            {
                return loadedTextures[filePath];
            }

            try
            {
                byte[] fileData = File.ReadAllBytes(filePath);
                Texture2D texture = LoadTextureFromBytes(fileData);
                if (texture != null)
                {
                    texture.name = Path.GetFileNameWithoutExtension(filePath);
                    loadedTextures[filePath] = texture;
                    return texture;
                }
            }
            catch (Exception ex)
            {
                Debug.LogError("Error loading texture: " + ex.Message);
            }
            return null;
        }
        private Texture2D LoadTextureFromBytes(byte[] fileData)
        {
            Texture2D texture = new Texture2D(2, 2, TextureFormat.RGBA32, true);
            texture.filterMode = FilterMode.Bilinear;
            if (texture.LoadImage(fileData))
            {
                return texture;
            }
            return null;
        }

        private void Start()
        {
            RefreshCameraList();
        }

        private void RefreshCameraList()
        {
            allCameras.Clear();
            allCameras.AddRange(UnityEngine.Object.FindObjectsOfType<Camera>());
            if (allCameras.Count > 0)
            {
                Debug.Log($"Found {allCameras.Count} cameras in the scene.");
                return;
            }
            Debug.LogWarning("No cameras found in the scene.");
        }

        private void Update()
        {
            HandleKeyboardInput();
            if (allCameras.Count > 0)
            {
                UpdateLookedAtObjectInfo();
            }
            UpdateRandomTextures();
            UpdateTextureAnimation();
            if (enableProceduralTextures)
            {
                ApplyProceduralTexture();
            }
        }

        private void HandleKeyboardInput()
        {
            if (Input.GetKeyDown(KeyCode.F1))
            {
                showGUI = !showGUI;
                Debug.Log("GUI visibility toggled: " + showGUI);
            }
            if (Input.GetKeyDown(KeyCode.F2))
            {
                RefreshCameraList();
            }
            if (Input.GetKeyDown(KeyCode.F3))
            {
                CycleCamera();
            }
            if (Input.GetKeyDown(KeyCode.F4))
            {
                showTexturePackBrowser = !showTexturePackBrowser;
                if (showTexturePackBrowser)
                {
                    RefreshTexturePacks();
                }
            }
        }

        private void CycleCamera()
        {
            currentCameraIndex = (currentCameraIndex + 1) % allCameras.Count;
            Debug.Log("Switched to camera: " + allCameras[currentCameraIndex].name);
        }

        private Camera GetCurrentCamera()
        {
            if (allCameras.Count == 0)
            {
                RefreshCameraList();
                if (allCameras.Count == 0)
                {
                    return null;
                }
            }
            return allCameras[currentCameraIndex];
        }
        private void UpdateLookedAtObjectInfo()
        {
            Camera currentCamera = GetCurrentCamera();
            if (currentCamera == null)
            {
                lookedAtObjectInfo = "No camera available";
                return;
            }

            RaycastHit raycastHit;
            if (Physics.Raycast(currentCamera.transform.position, currentCamera.transform.forward, out raycastHit, 100f))
            {
                lookedAtObjectInfo = "Looking at: " + raycastHit.transform.name + "\n";
                Renderer component = raycastHit.transform.GetComponent<Renderer>();
                if (component != null && component.material != null)
                {
                    Material material = component.material;
                    lookedAtObjectInfo += "Material: " + material.name + "\n";
                    lookedAtObjectInfo += "Shader: " + material.shader.name + "\n";

                    foreach (string propertyName in material.GetTexturePropertyNames())
                    {
                        Texture texture = material.GetTexture(propertyName);
                        if (texture != null)
                        {
                            Vector2 tiling = material.GetTextureScale(propertyName);
                            Vector2 offset = material.GetTextureOffset(propertyName);
                            lookedAtObjectInfo += $"Texture: {propertyName} - {texture.name}\n";
                            lookedAtObjectInfo += $"Tiling: ({tiling.x}, {tiling.y})\n";
                            lookedAtObjectInfo += $"Offset: ({offset.x}, {offset.y})\n";
                        }
                    }
                    return;
                }
                lookedAtObjectInfo += "No Renderer or Material found on this object.";
            }
            else
            {
                lookedAtObjectInfo = "Not looking at any object";
            }
        }

        private void OnGUI()
        {
            if (showGuiButton)
            {
                if (GUI.Button(new Rect(Screen.width - 100, 10, 90, 30), "Toggle GUI"))
                {
                    showGUI = !showGUI;
                }
            }

            if (showGUI)
            {
                if (showTexturePackBrowser)
                {
                    windowRect = GUI.Window(1, new Rect(530f, 20f, 300f, 400f), DrawTexturePackBrowser, "Texture Pack Browser");
                }
                else
                {
                    windowRect = defaultWindowRect;
                }
                windowRect = GUI.Window(0, windowRect, DrawWindow, "Texture Replacer");
            }
        }

        private void StoreOriginalTexture(GameObject obj, Material material)
        {
            if (!originalTextures.ContainsKey(obj))
            {
                originalTextures[obj] = new Dictionary<string, Texture>();
            }

            foreach (string propertyName in material.GetTexturePropertyNames())
            {
                if (material.HasProperty(propertyName) && !originalTextures[obj].ContainsKey(propertyName))
                {
                    originalTextures[obj][propertyName] = material.GetTexture(propertyName);
                }
            }
        }

        private void RestoreOriginalTextures()
        {
            int restoredCount = 0;
            foreach (var objEntry in originalTextures)
            {
                GameObject obj = objEntry.Key;
                if (obj != null)
                {
                    Renderer renderer = obj.GetComponent<Renderer>();
                    if (renderer != null && renderer.material != null)
                    {
                        foreach (var textureEntry in objEntry.Value)
                        {
                            if (textureEntry.Value != null)
                            {
                                renderer.material.SetTexture(textureEntry.Key, textureEntry.Value);
                                renderer.material.SetTextureScale(textureEntry.Key, Vector2.one);
                                renderer.material.SetTextureOffset(textureEntry.Key, Vector2.zero);
                                restoredCount++;
                            }
                        }
                    }
                }
            }
            Debug.Log($"Restored {restoredCount} original textures");
            statusMessage = $"Restored {restoredCount} original textures";
        }

        private void DrawTexturePackBrowser(int windowID)
        {
            GUILayout.BeginVertical();
            if (GUILayout.Button("Refresh Texture Packs"))
            {
                RefreshTexturePacks();
            }
            texturePackScrollPosition = GUILayout.BeginScrollView(texturePackScrollPosition);
            foreach (string packName in availableTexturePacks)
            {
                if (GUILayout.Button(packName))
                {
                    selectedTexturePack = packName;
                    string fullPath = Path.Combine(texturePacksFolder, packName);
                    texturePackPath = fullPath;
                    ImportTexturePack();
                }
            }
            GUILayout.EndScrollView();
            if (!string.IsNullOrEmpty(selectedTexturePack))
            {
                GUILayout.Label("Selected Pack: " + selectedTexturePack);
            }
            if (GUILayout.Button("Close Browser"))
            {
                showTexturePackBrowser = false;
            }
            GUILayout.EndVertical();
            GUI.DragWindow();
        }
        private void DrawWindow(int windowID)
        {
            scrollPosition = GUILayout.BeginScrollView(scrollPosition);

            GUILayout.Label("Texture Path:");
            texturePath = GUILayout.TextField(texturePath);

            if (GUILayout.Button("Load Texture"))
            {
                LoadPlayerTexture();
            }

            if (GUILayout.Button("Browse Texture Packs"))
            {
                showTexturePackBrowser = !showTexturePackBrowser;
                if (showTexturePackBrowser)
                {
                    RefreshTexturePacks();
                }
            }

            if (GUILayout.Button("Restore Original Textures"))
            {
                RestoreOriginalTextures();
            }

            if (GUILayout.Button("Hide Toggle Button"))
            {
                showGuiButton = !showGuiButton;
            }

            GUILayout.Label("Tile Size:");
            tileSize = GUILayout.HorizontalSlider(tileSize, 0.1f, 10f);

            GUILayout.Label("Blur Amount:");
            blurAmount = GUILayout.HorizontalSlider(blurAmount, 0f, 10f);

            GUILayout.Label("Texture Scale:");
            textureScale = GUILayout.HorizontalSlider(textureScale, 0.1f, 2f);

            GUILayout.Label("Pixelation Amount:");
            pixelationAmount = GUILayout.HorizontalSlider(pixelationAmount, 1f, 64f);

            GUILayout.Label("Quality:");
            qualitySlider = GUILayout.HorizontalSlider(qualitySlider, 0.1f, 1f);

            GUILayout.Label("Repetition Count:");
            repetitionCountInput = GUILayout.TextField(repetitionCountInput);
            int newRepetitionCount;
            if (int.TryParse(repetitionCountInput, out newRepetitionCount))
            {
                if (newRepetitionCount > 0 && newRepetitionCount <= 10)
                {
                    if (repetitionCount != newRepetitionCount)
                    {
                        repetitionCount = newRepetitionCount;
                        if (playerTexture != null)
                        {
                            LoadPlayerTexture();
                        }
                    }
                }
            }

            GUILayout.Label("Darkness:");
            darknessAmount = GUILayout.HorizontalSlider(darknessAmount, 0f, 1f);

            GUILayout.Label("Contrast:");
            contrastAmount = GUILayout.HorizontalSlider(contrastAmount, 0.5f, 2f);

            DrawTextureControls();
            DrawAdvancedControls();

            GUILayout.EndScrollView();
            GUI.DragWindow();
        }

        private void DrawTextureControls()
        {
            if (GUILayout.Button("Set to Normal"))
            {
                SetToNormalSettings();
            }

            if (GUILayout.Button("Replace Texture on Looked At Object"))
            {
                ReplaceTextureOnSingleObject(texturePath);
            }

            if (GUILayout.Button("Replace Texture on Similar Objects"))
            {
                ReplaceTextureOnSimilarObjects(texturePath);
            }

            GUILayout.Label("Enter texture pack path (.zip):");
            texturePackPath = GUILayout.TextField(texturePackPath);

            if (GUILayout.Button("Import Texture Pack"))
            {
                ImportTexturePack();
            }
        }
        private void DrawAdvancedControls()
        {
            GUILayout.Label("Status: " + statusMessage);
            GUILayout.Label("Looked At Object Info:");
            GUILayout.Label(lookedAtObjectInfo);

            if (GUILayout.Button("Get Looked At Texture Name"))
            {
                GetLookedAtTextureName();
            }

            textureNameScrollPosition = GUILayout.BeginScrollView(textureNameScrollPosition);
            GUILayout.Label(lookedAtTextureName);
            GUILayout.EndScrollView();

            DrawRandomTextureControls();
            DrawAnimationControls();
            DrawProceduralControls();
        }

        private void DrawRandomTextureControls()
        {
            GUILayout.Label("Random Texture Replacement");
            enableRandomTextures = GUILayout.Toggle(enableRandomTextures, "Enable Random Textures");
            GUILayout.Label("Random Texture Interval:");
            randomTextureInterval = GUILayout.HorizontalSlider(randomTextureInterval, 1f, 60f);

            if (GUILayout.Button("Add Texture to Pool"))
            {
                string newTexturePath = UnityEngine.Application.dataPath + "/Textures/";
                if (!string.IsNullOrEmpty(newTexturePath))
                {
                    texturePool.Add(newTexturePath);
                }
            }
        }

        private void DrawAnimationControls()
        {
            GUILayout.Label("Texture Animation");
            enableTextureAnimation = GUILayout.Toggle(enableTextureAnimation, "Enable Texture Animation");
            GUILayout.Label("Animation Speed:");
            textureAnimationSpeed = GUILayout.HorizontalSlider(textureAnimationSpeed, 0.1f, 10f);

            if (GUILayout.Button("Add Animation Frame"))
            {
                string newFramePath = UnityEngine.Application.dataPath + "/Textures/";
                if (!string.IsNullOrEmpty(newFramePath))
                {
                    Texture2D newFrame = LoadTextureFromFile(newFramePath);
                    if (newFrame != null)
                    {
                        animationFrames.Add(newFrame);
                    }
                }
            }
        }

        private void DrawProceduralControls()
        {
            GUILayout.Label("Procedural Texture Generation");
            enableProceduralTextures = GUILayout.Toggle(enableProceduralTextures, "Enable Procedural Textures");
            GUILayout.Label("Noise Scale:");
            proceduralNoiseScale = GUILayout.HorizontalSlider(proceduralNoiseScale, 0.01f, 0.1f);

            GUILayout.Label("Color 1:");
            proceduralColor1 = DrawColorSliders(proceduralColor1);

            GUILayout.Label("Color 2:");
            proceduralColor2 = DrawColorSliders(proceduralColor2);
        }

        private Color DrawColorSliders(Color color)
        {
            return new Color(
                GUILayout.HorizontalSlider(color.r, 0f, 1f),
                GUILayout.HorizontalSlider(color.g, 0f, 1f),
                GUILayout.HorizontalSlider(color.b, 0f, 1f)
            );
        }
        private void SetToNormalSettings()
        {
            tileSize = 1f;
            blurAmount = 0f;
            textureScale = 1f;
            pixelationAmount = 1f;
            qualitySlider = 1f;
            repetitionCountInput = "1";
            repetitionCount = 1;
            darknessAmount = 0.5f;
            contrastAmount = 1.2f;
            statusMessage = "Settings reset to normal values.";
        }

        private Texture2D PixelateTexture(Texture2D source, int pixelSize)
        {
            int width = source.width;
            int height = source.height;
            Color[] pixels = source.GetPixels();
            Color[] newPixels = new Color[pixels.Length];

            for (int y = 0; y < height; y += pixelSize)
            {
                for (int x = 0; x < width; x += pixelSize)
                {
                    Color averageColor = Color.black;
                    int count = 0;

                    for (int py = 0; py < pixelSize && y + py < height; py++)
                    {
                        for (int px = 0; px < pixelSize && x + px < width; px++)
                        {
                            averageColor += pixels[(y + py) * width + (x + px)];
                            count++;
                        }
                    }
                    averageColor /= count;

                    for (int py = 0; py < pixelSize && y + py < height; py++)
                    {
                        for (int px = 0; px < pixelSize && x + px < width; px++)
                        {
                            newPixels[(y + py) * width + (x + px)] = averageColor;
                        }
                    }
                }
            }

            Texture2D result = new Texture2D(width, height);
            result.SetPixels(newPixels);
            result.Apply();
            return result;
        }

        private Texture2D AdjustDarknessAndContrast(Texture2D source, float darkness, float contrast)
        {
            int width = source.width;
            int height = source.height;
            Color[] pixels = source.GetPixels();
            Color[] newPixels = new Color[pixels.Length];

            for (int i = 0; i < pixels.Length; i++)
            {
                Color pixel = pixels[i];
                pixel = Color.Lerp(pixel, Color.black, darkness);
                pixel.r = (pixel.r - 0.5f) * contrast + 0.5f;
                pixel.g = (pixel.g - 0.5f) * contrast + 0.5f;
                pixel.b = (pixel.b - 0.5f) * contrast + 0.5f;
                newPixels[i] = pixel;
            }

            Texture2D result = new Texture2D(width, height);
            result.SetPixels(newPixels);
            result.Apply();
            return result;
        }
        private Texture2D ApplyBlur(Texture2D source, float blurSize)
        {
            int width = source.width;
            int height = source.height;
            Color[] pixels = source.GetPixels();
            Color[] newPixels = new Color[pixels.Length];
            int kernelSize = Mathf.CeilToInt(blurSize * 2f);

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    Color sum = Color.black;
                    int count = 0;

                    for (int ky = -kernelSize; ky <= kernelSize; ky++)
                    {
                        for (int kx = -kernelSize; kx <= kernelSize; kx++)
                        {
                            int sampleX = Mathf.Clamp(x + kx, 0, width - 1);
                            int sampleY = Mathf.Clamp(y + ky, 0, height - 1);
                            sum += pixels[sampleY * width + sampleX];
                            count++;
                        }
                    }
                    newPixels[y * width + x] = sum / count;
                }
            }

            Texture2D result = new Texture2D(width, height);
            result.SetPixels(newPixels);
            result.Apply();
            return result;
        }

        private void ImportTexturePack()
        {
            if (string.IsNullOrEmpty(texturePackPath) || !File.Exists(texturePackPath))
            {
                statusMessage = "Invalid texture pack path.";
                return;
            }

            try
            {
                Dictionary<string, Texture2D> objectTextures = new Dictionary<string, Texture2D>();
                using (ZipArchive archive = ZipFile.OpenRead(texturePackPath))
                {
                    ZipArchiveEntry configEntry = archive.GetEntry("config.txt");
                    if (configEntry == null)
                    {
                        statusMessage = "config.txt not found in the texture pack.";
                        return;
                    }

                    using (StreamReader reader = new StreamReader(configEntry.Open()))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {
                            string[] parts = line.Split(new char[] { '=' }, 2);
                            if (parts.Length == 2)
                            {
                                string objectName = parts[0].Trim();
                                string fileName = parts[1].Trim();

                                ZipArchiveEntry textureEntry = archive.GetEntry(fileName);
                                if (textureEntry != null)
                                {
                                    using (Stream stream = textureEntry.Open())
                                    {
                                        byte[] textureData = new byte[textureEntry.Length];
                                        stream.Read(textureData, 0, textureData.Length);
                                        Texture2D texture = LoadTextureFromBytes(textureData);
                                        if (texture != null)
                                        {
                                            if (repetitionCount > 1)
                                            {
                                                texture = CreateTiledTexture(texture, repetitionCount);
                                            }
                                            objectTextures[objectName] = texture;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                ApplyTexturesToObjects(objectTextures);
                statusMessage = "Texture pack imported and applied successfully.";
            }
            catch (Exception ex)
            {
                statusMessage = "Error importing texture pack: " + ex.Message;
                Debug.LogError("Texture pack import error: " + ex);
            }
        }
        private void ApplyTexturesToObjects(Dictionary<string, Texture2D> objectTextures)
        {
            foreach (KeyValuePair<string, Texture2D> kvp in objectTextures)
            {
                string objectName = kvp.Key;
                Texture2D newTexture = kvp.Value;
                GameObject[] matchingObjects = UnityEngine.Object.FindObjectsOfType<GameObject>()
                    .Where(obj => obj.name.ToLower().Contains(objectName.ToLower()))
                    .ToArray();

                foreach (GameObject obj in matchingObjects)
                {
                    Renderer renderer = obj.GetComponent<Renderer>();
                    if (renderer != null && renderer.sharedMaterial != null)
                    {
                        Material material = renderer.sharedMaterial;
                        foreach (string propertyName in material.GetTexturePropertyNames())
                        {
                            if (material.HasProperty(propertyName))
                            {
                                material.SetTexture(propertyName, newTexture);
                                material.SetTextureScale(propertyName, new Vector2(repetitionCount, repetitionCount));
                                material.SetTextureOffset(propertyName, Vector2.zero);
                            }
                        }
                    }
                }
            }
        }

        private void ReplaceTextureOnSimilarObjects(string path)
        {
            Texture2D newTexture = LoadTextureFromFile(path);
            if (newTexture == null)
            {
                statusMessage = "Failed to load texture from file.";
                return;
            }

            if (repetitionCount > 1)
            {
                newTexture = CreateTiledTexture(newTexture, repetitionCount);
            }

            Camera currentCamera = GetCurrentCamera();
            if (currentCamera == null)
            {
                statusMessage = "No active camera found!";
                return;
            }

            RaycastHit raycastHit;
            if (Physics.Raycast(currentCamera.transform.position, currentCamera.transform.forward, out raycastHit, 100f))
            {
                Renderer targetRenderer = raycastHit.transform.GetComponent<Renderer>();
                if (targetRenderer != null && targetRenderer.sharedMaterial != null)
                {
                    Material targetMaterial = targetRenderer.sharedMaterial;
                    Renderer[] allRenderers = UnityEngine.Object.FindObjectsOfType<Renderer>();
                    int replacementCount = 0;

                    foreach (Renderer renderer in allRenderers)
                    {
                        if (renderer.sharedMaterial != null &&
                            renderer.sharedMaterial.name == targetMaterial.name)
                        {
                            foreach (string propertyName in renderer.sharedMaterial.GetTexturePropertyNames())
                            {
                                if (renderer.sharedMaterial.HasProperty(propertyName))
                                {
                                    renderer.sharedMaterial.SetTexture(propertyName, newTexture);
                                    renderer.sharedMaterial.SetTextureScale(propertyName, new Vector2(repetitionCount, repetitionCount));
                                    renderer.sharedMaterial.SetTextureOffset(propertyName, Vector2.zero);
                                    replacementCount++;
                                }
                            }
                        }
                    }
                    statusMessage = $"Replaced textures on {replacementCount} similar objects.";
                    return;
                }
                statusMessage = "No valid renderer or material found on the looked at object.";
                return;
            }
            statusMessage = "No object detected in front of the camera.";
        }
        private void ReplaceTextureOnSingleObject(string path)
        {
            Texture2D newTexture = LoadTextureFromFile(path);
            if (newTexture == null)
            {
                statusMessage = "Failed to load texture from file.";
                return;
            }

            if (repetitionCount > 1)
            {
                newTexture = CreateTiledTexture(newTexture, repetitionCount);
            }

            Camera currentCamera = GetCurrentCamera();
            if (currentCamera == null)
            {
                statusMessage = "No active camera found!";
                return;
            }

            RaycastHit raycastHit;
            if (Physics.Raycast(currentCamera.transform.position, currentCamera.transform.forward, out raycastHit, 100f))
            {
                Renderer renderer = raycastHit.transform.GetComponent<Renderer>();
                if (renderer != null)
                {
                    Material material = renderer.material;
                    foreach (string propertyName in material.GetTexturePropertyNames())
                    {
                        if (material.HasProperty(propertyName))
                        {
                            material.SetTexture(propertyName, newTexture);
                            material.SetTextureScale(propertyName, new Vector2(repetitionCount, repetitionCount));
                            material.SetTextureOffset(propertyName, Vector2.zero);
                        }
                    }
                    statusMessage = "Texture replaced successfully on " + raycastHit.transform.name;
                    return;
                }
                statusMessage = "No Renderer found on the looked at object.";
                return;
            }
            statusMessage = "No object detected in front of the camera.";
        }



        private void GetLookedAtTextureName()
        {
            Camera currentCamera = GetCurrentCamera();
            if (currentCamera == null)
            {
                lookedAtTextureName = "No camera available";
                return;
            }

            RaycastHit hit;
            if (Physics.Raycast(currentCamera.transform.position, currentCamera.transform.forward, out hit, 100f))
            {
                Renderer renderer = hit.transform.GetComponent<Renderer>();
                if (renderer != null && renderer.material != null)
                {
                    lookedAtTextureName = "Textures on " + hit.transform.name + ":\n";
                    foreach (string propertyName in renderer.material.GetTexturePropertyNames())
                    {
                        Texture texture = renderer.material.GetTexture(propertyName);
                        if (texture != null)
                        {
                            Vector2 tiling = renderer.material.GetTextureScale(propertyName);
                            lookedAtTextureName += $"{propertyName}: {texture.name} (Tiling: {tiling.x}x{tiling.y})\n";
                        }
                    }
                }
                else
                {
                    lookedAtTextureName = "No textures found on object";
                }
            }
            else
            {
                lookedAtTextureName = "Not looking at any object";
            }
        }
        private void UpdateRandomTextures()
        {
            if (!enableRandomTextures || texturePool.Count == 0)
                return;

            if (Time.time - lastRandomTextureTime >= randomTextureInterval)
            {
                int randomIndex = UnityEngine.Random.Range(0, texturePool.Count);
                string randomTexturePath = texturePool[randomIndex];
                Texture2D randomTexture = LoadTextureFromFile(randomTexturePath);
                if (randomTexture != null)
                {
                    if (repetitionCount > 1)
                    {
                        randomTexture = CreateTiledTexture(randomTexture, repetitionCount);
                    }
                    ReplaceTextureOnAllObjects(null, randomTexture);
                }
                lastRandomTextureTime = Time.time;
            }
        }

        private void ReplaceTextureOnAllObjects(Texture originalTexture, Texture2D newTexture)
        {
            Renderer[] allRenderers = UnityEngine.Object.FindObjectsOfType<Renderer>();
            int replacementCount = 0;

            foreach (Renderer renderer in allRenderers)
            {
                if (renderer != null && renderer.material != null)
                {
                    StoreOriginalTexture(renderer.gameObject, renderer.material);

                    Material material = renderer.material;
                    foreach (string propertyName in material.GetTexturePropertyNames())
                    {
                        if (material.HasProperty(propertyName))
                        {
                            Texture currentTexture = material.GetTexture(propertyName);
                            if (originalTexture == null || currentTexture == originalTexture)
                            {
                                material.SetTexture(propertyName, newTexture);
                                material.SetTextureScale(propertyName, new Vector2(repetitionCount, repetitionCount));
                                material.SetTextureOffset(propertyName, Vector2.zero);
                                replacementCount++;
                            }
                        }
                    }
                }
            }

            Debug.Log($"Replaced {replacementCount} textures across all objects");
        }


        private void UpdateTextureAnimation()
        {
            if (!enableTextureAnimation || animationFrames.Count == 0)
                return;

            float frameTime = 1f / textureAnimationSpeed;
            if (Time.time - lastRandomTextureTime >= frameTime)
            {
                currentAnimationFrame = (currentAnimationFrame + 1) % animationFrames.Count;
                Texture2D currentFrame = animationFrames[currentAnimationFrame];
                if (currentFrame != null)
                {
                    Texture2D tiledFrame = repetitionCount > 1 ? CreateTiledTexture(currentFrame, repetitionCount) : currentFrame;
                    ReplaceTextureOnAllObjects(null, tiledFrame);
                }
                lastRandomTextureTime = Time.time;
            }
        }

        private void ApplyProceduralTexture()
        {
            int textureSize = 256;
            Texture2D proceduralTexture = new Texture2D(textureSize, textureSize);

            for (int y = 0; y < textureSize; y++)
            {
                for (int x = 0; x < textureSize; x++)
                {
                    float perlinValue = Mathf.PerlinNoise(
                        x * proceduralNoiseScale,
                        y * proceduralNoiseScale
                    );
                    Color pixelColor = Color.Lerp(proceduralColor1, proceduralColor2, perlinValue);
                    proceduralTexture.SetPixel(x, y, pixelColor);
                }
            }

            proceduralTexture.Apply();

            if (repetitionCount > 1)
            {
                proceduralTexture = CreateTiledTexture(proceduralTexture, repetitionCount);
            }

            ReplaceTextureOnAllObjects(null, proceduralTexture);
        }

    }
}
